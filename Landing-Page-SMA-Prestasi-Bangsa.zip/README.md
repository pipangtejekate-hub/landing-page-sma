# Landing Page - SMA Prestasi Bangsa

## Deskripsi
Landing page resmi untuk instansi sekolah (SMA) yang modern, responsif, dan siap digunakan.

## Framework & Teknologi yang Digunakan

| Teknologi          | Keterangan                                      |
|--------------------|-------------------------------------------------|
| **Tailwind CSS**   | Framework CSS utama (utility-first) via CDN     |
| **HTML5**          | Struktur halaman                                |
| **JavaScript**     | Vanilla JS (mobile menu, smooth scroll, dll)    |
| **Font Awesome 6** | Icon library                                    |
| **Google Fonts**   | Font Inter                                      |

## Fitur yang Tersedia

- Navbar fixed + responsive (mobile menu)
- Hero section dengan statistik
- Tentang Sekolah (Visi, Misi, Nilai)
- Program Unggulan (IPA, IPS, Digital)
- Fasilitas Sekolah
- Prestasi Siswa
- Call to Action (PPDB)
- Halaman Kontak + Form
- Footer lengkap
- Tombol Back to Top
- Fully Responsive (Mobile, Tablet, Desktop)

## Cara Menjalankan

1. Buka file `index.html` menggunakan browser (Chrome, Edge, Firefox, dll)
2. Tidak perlu install apapun — langsung bisa dibuka offline
3. Untuk development lebih lanjut, bisa pakai Live Server di VS Code

## Struktur File

```
├── index.html      → File utama landing page
└── README.md       → Dokumentasi project
```

## Catatan untuk Tugas

- Landing page ini sudah **siap dikumpulkan**
- Semua section sudah lengkap dan berfungsi
- Desain modern dan profesional
- Kode bersih dan terstruktur

---
Dibuat untuk keperluan tugas / project sekolah.
